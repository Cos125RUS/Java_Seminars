package org.example.human;

public interface Transport {
    void start();
    void stop();
}
