package org.example.game;

public enum GameStatus {
    INIT,START,WIN,LOSE
}
