package org.example;

public class Calendar {
    Month month2 = Month.FEB;

}
